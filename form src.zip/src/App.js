import logo from './logo.svg';
import './App.css';
import SignUpForm from './component/SignUpForm';

function App() {
  return (
   <>
   <SignUpForm/>
   </>
  );
}

export default App;
