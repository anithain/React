import React from 'react'
import '../assets/css/signUp.css'
import {useForm} from'react-hook-form'
import { yupResolver} from "@hookform/resolvers/yup"
import * as yup from "yup"
const SignUpForm = () => {

    const formSchema = yup.object({
        first_name:yup.string().required('First Name is Required'),
        last_name:yup.string().required('Last Name is required'),
    })

    const{
        register,
        handleSubmit,
        formState:{errors},
    }=useForm({
        resolver:yupResolver(formSchema)
    })

const onSubmit = (data) => {
    console.log(data)
}

  return (
    <div className="container">
        <h2>Sign Up</h2>
        <form onSubmit={handleSubmit(onSubmit)}>
            <div className="form-group">
                <label>First Name</label>
                <input type="text" name='first_name' {...register('first_name')} />
                <p style={{color:'red'}}>{errors.first_name?.message}</p>
            </div>

            <div className="form-group">
                <label>Last Name</label>
                <input type="text" name='last_name' {...register('last_name')} />
                <p style={{color:'red'}}>{errors.last_name?.message}</p>
            </div>
            <input type="submit" value="Sign Up"/>
        </form>
      
    </div>
  )
}

export default SignUpForm


