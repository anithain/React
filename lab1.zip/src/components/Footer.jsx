function Footer(){
    return (
        // <!--Footer Starts HERE-->
        <footer class="footer">
            <div class="wrapper">
                <p>&copy; <a href="#">House Rental System</a>. All rights reserved 2017.</p>
            </div>
        </footer>
        // <!--Footer Ends HERE-->
    );
}

export default Footer;