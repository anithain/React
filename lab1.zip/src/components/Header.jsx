function Header(){
    return(
        // <!--Header Starts HERE-->
        <header class="header">
            <div class="wrapper">
                <h1>HOUSE RENTAL SYSTEM</h1>
            </div>
            
        </header>
    )
}

export default Header;