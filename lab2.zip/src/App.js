import logo from './logo.svg';
import './App.css';
import { Routes,Route} from 'react-router-dom'
import CustomerCare from './components/CustomerCare';
import Products from './components/Products';
import Services from './components/Services';

function App() {
  return (

    <Routes>
      <Route path='/Services' element={<Services/>}/>
      <Route path='/Products' element={<Products/>}/>
      <Route path='/CustomerCare' element={<CustomerCare/>}/>
    </Routes>
  );
}

export default App;
