function CustomerCare(){
    return (
        <h1>This is customer care page</h1>
    )
}

export default CustomerCare;