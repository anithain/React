function Products(){
    return (
        <h1>This is Product page</h1>
    )
}

export default Products;