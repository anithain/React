import React from 'react'
import '../assets/css/common.css'
const Header = () => {
    return (
        <div class="header">
            <h3>News Reader App </h3>
        </div>
    )
}

export default Header
